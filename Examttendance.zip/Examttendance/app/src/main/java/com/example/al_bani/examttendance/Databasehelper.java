package com.example.al_bani.examttendance;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by Al-Bani on 5/31/2018.
 */


public class Databasehelper  extends SQLiteOpenHelper {

public static final String DATABASE_NAME = "mdi.db";
    public static final String TABLE_NAME = "admin_table";
    public static final String TABLE_NAMES = "student_table";
    public static final String TABLE_ADT = "atd";
    public static final String COL_1= "id";
    public static final String COL_2= "name";
    public static final String COL_3= "username";
    public static final String COL_4= "password";
    public static final String COL_5= "email";
    public static final String COL_8= "s_id";
    public static final String COL_6= "reg";
    public static final String COL_7= "in";
    public static final String COL_9= "out";
    public static final String COL_10= "course";
    public static final String COL_11= "a_id";
    public static final String COL_01= "level";
    public static final String TABLE_NAMESS = "tablest";
    public static final String TATD= "atd_table";
    public static final String TCOURSE= "course_table";

    public Databasehelper(Context context) {
        super(context, DATABASE_NAME, null,2);


    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table  " + TABLE_NAME + " ( id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT,"  +
               " username TEXT, password TEXT, email TEXT  )");
        db.execSQL("create table " + TABLE_NAMES + " ( s_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "name TEXT, level TEXT, reg TEXT, email TEXT, time TEXT  )");



    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
         db.execSQL("DROP TABLE IF EXISTS " +TABLE_NAME);
         db.execSQL("DROP TABLE IF EXISTS " +TABLE_NAMES);



         onCreate(db);


    }

    public boolean insertdata(String Name, String Username, String Password, String Email){
        SQLiteDatabase db= this.getWritableDatabase();
        ContentValues ContentValues= new ContentValues();
        ContentValues.put(COL_2, Name);
        ContentValues.put(COL_3, Username);
        ContentValues.put(COL_4, Password);
        ContentValues.put(COL_5, Email);
        Long result = db.insert(TABLE_NAME, null, ContentValues);
if(result == -1){
    return false;
}
else{
    return true;
}
    }
//insert admin
    public Cursor getAlldata(){
        SQLiteDatabase db= this.getWritableDatabase();
        Cursor res= db.rawQuery("select * from " + TABLE_NAME, null);
 return res;


    }

    public  Cursor getlog(String user, String pass){

            SQLiteDatabase db= this.getWritableDatabase();
            Cursor di= db.rawQuery("select * from "+TABLE_NAME+" where  " + COL_3 + "=? AND " +COL_4 + "=?", new String[]{user, pass});
            return di;


    }
    public Cursor getserach(String user){
        SQLiteDatabase db= this.getWritableDatabase();
        Cursor ups= db.rawQuery("select * from "+TABLE_NAME+" where name='"+user+"'", null);
        return ups;
    }

    public Cursor getid(String user){
        SQLiteDatabase db= this.getWritableDatabase();
        Cursor ups= db.rawQuery("select * from "+TABLE_NAME+" where id='"+user+"'", null);
        return ups;
    }

    public boolean updatedata(String Name, String Username, String Password, String Email){
        SQLiteDatabase db= this.getWritableDatabase();
        ContentValues ContentValues= new ContentValues();
        ContentValues.put(COL_2, Name);
        ContentValues.put(COL_3, Username);
        ContentValues.put(COL_4, Password);
        ContentValues.put(COL_5, Email);
        db.update(TABLE_NAME, ContentValues, "name=?", new String[]{Name});
        return true;
    }
    public boolean deleteall(String user) {
        SQLiteDatabase db = this.getWritableDatabase();

        db.execSQL("Delete from "+TABLE_NAME+" where id='"+user+"'");

        return true;
    }


    //student
    public boolean insertstudent(String name, String level, String reg, String email){
        SQLiteDatabase db= this.getWritableDatabase();
        ContentValues ContentValues= new ContentValues();
        ContentValues.put(COL_2, name);
        ContentValues.put(COL_01,level );
        ContentValues.put(COL_6, reg);
        ContentValues.put(COL_5, email);
        Long result = db.insert(TABLE_NAMES, null, ContentValues);
        if(result == -1){
            return false;
        }
        else{
            return true;
        }
    }

//update student
    public boolean updatestd(String Name, String LEVEL, String REG, String Email){
        SQLiteDatabase db= this.getWritableDatabase();
        ContentValues ContentValues= new ContentValues();
        ContentValues.put(COL_2, Name);
        ContentValues.put(COL_01, LEVEL);
        ContentValues.put(COL_6, REG);
        ContentValues.put(COL_5, Email);
        db.update(TABLE_NAMES, ContentValues, "name=?", new String[]{Name});
        return true;
    }

    public Cursor getAllstudent(){
        SQLiteDatabase db= this.getWritableDatabase();
        Cursor res= db.rawQuery("select * from "+TABLE_NAMES, null);
        return res;


    }

    public Cursor getserachs(String user){
        SQLiteDatabase db= this.getWritableDatabase();
        Cursor ups= db.rawQuery("select * from "+TABLE_NAMES+" where name='"+user+"'", null);
        return ups;
    }

    public Cursor getids(String user){
        SQLiteDatabase db= this.getWritableDatabase();
        Cursor ups= db.rawQuery("select * from "+TABLE_NAMES+" where s_id='"+user+"'", null);
        return ups;
    }
    public boolean deletstd(String user) {
        SQLiteDatabase db = this.getWritableDatabase();

        db.execSQL("Delete from "+TABLE_NAMES+" where s_id='"+user+"'");

        return true;
    }

    //atd

    public Cursor getAllad(){
        SQLiteDatabase db= this.getWritableDatabase();
        Cursor res= db.rawQuery("select * from "+TABLE_ADT, null);
        return res;


    }
    public Cursor getserachin(String reg, String in ){
        SQLiteDatabase db= this.getWritableDatabase();
        Cursor ups= db.rawQuery("select * from "+TABLE_NAMES+" where name='"+reg+"' and level='"+in+"'", null);
        return ups;
    }
    public Cursor getserachout(String user, String in){
        String MD="YES";
        SQLiteDatabase db= this.getWritableDatabase();
        Cursor ups= db.rawQuery("select * from "+TABLE_NAMES+" where name='"+user+"' and level='"+in+"' and reg='"+MD+"'",  null);
        return ups;
    }

    public boolean sout(String Name){
        SQLiteDatabase db= this.getWritableDatabase();
        ContentValues ContentValues= new ContentValues();
        ContentValues.put(COL_5, Name);
        db.update(TABLE_NAMES, ContentValues, "name=?", new String[]{Name});
        return true;
    }

    public boolean insert(String Name, String Username, String Password, String Email){
        SQLiteDatabase db= this.getWritableDatabase();
        ContentValues ContentValues= new ContentValues();
        ContentValues.put(COL_2, Name);
        ContentValues.put(COL_3, Username);
        ContentValues.put(COL_4, Password);
        ContentValues.put(COL_5, Email);
        Long result = db.insert(TABLE_NAMESS, null, ContentValues);
        if(result == -1){
            return false;
        }
        else{
            return true;
        }
    }


}
