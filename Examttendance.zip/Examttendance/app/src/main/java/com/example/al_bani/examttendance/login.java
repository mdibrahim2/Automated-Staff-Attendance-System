package com.example.al_bani.examttendance;


import android.content.Intent;
import android.database.Cursor;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class login extends AppCompatActivity implements View.OnClickListener {
    Databasehelper myd;
    Cursor cursor;

    EditText _txtEmail, _txtPass;
    EditText username, password;
    Button loginbtn;

    String user, pass;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        myd = new Databasehelper(this);

        setContentView(R.layout.activity_login);
        username = (EditText) findViewById(R.id.username);
        password = (EditText) findViewById(R.id.password);
        loginbtn = (Button) findViewById(R.id.loginbtn);
        loginbtn.setOnClickListener(this);




    }

    @Override
    public void onClick(View v) {



        if (v.getId() == R.id.loginbtn) {


            user = username.getText().toString().trim();
            pass = password.getText().toString().trim();
            if (user.equals("") || pass.equals("")) {
                Toast.makeText(this, "Empty field are not allowed", Toast.LENGTH_SHORT).show();
                return;
            }
           Cursor  cursor = myd.getlog(user,pass);
            if (cursor != null) {
                if (cursor.getCount() > 0) {
                    Intent intent =  new Intent(login.this, menu.class);
                    startActivity(intent);

                } else {
                    Toast.makeText(getApplicationContext(), "Login error", Toast.LENGTH_SHORT).show();
                }
            }




        }
    }
}