package com.example.al_bani.examttendance;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class mdi extends AppCompatActivity {
    Button viewa, exit, about, signin,signout, view;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mdi);
        signin = (Button) findViewById(R.id.signin);
        signout = (Button) findViewById(R.id.signout);
        about=(Button) findViewById(R.id.about);
        exit=(Button) findViewById(R.id.exit);
md();
    }

    public void md() {

        signin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent =  new Intent(mdi.this, m.class);
                startActivity(intent);

            }
        });
        exit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent =  new Intent(mdi.this, attendace.class);
                startActivity(intent);
            }
        });
        signout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent =  new Intent(mdi.this, sout.class);
                startActivity(intent);
            }
        });




    }


}
