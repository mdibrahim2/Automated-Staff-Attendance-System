package com.example.al_bani.examttendance;

import android.database.Cursor;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.zxing.Result;

import java.util.ArrayList;

import me.dm7.barcodescanner.zxing.ZXingScannerView;

public class sout extends AppCompatActivity implements ZXingScannerView.ResultHandler {
    Databasehelper myd;
    String name, reg, in,t, out;
    String email;
    EditText editsearch;
    Button save, viewall, all,  update;
    Spinner course;


    ArrayList<String> my = new ArrayList<>();

    private ZXingScannerView zXingScannerView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sout);
        myd= new Databasehelper(this);
        viewall= (Button) findViewById(R.id.viewall);
        course =(Spinner) findViewById(R.id.course);
        //CREATE row for spinner
        my.add("CSC1301");
        my.add("CSC1302");
        my.add("CSC130");
        my.add("CSC2302");
        my.add("CSC3301");
        my.add("CSC4302");


        //creating adapter for spinner
        ArrayAdapter<String> adapter = new ArrayAdapter<>(sout.this,
                android.R.layout.simple_spinner_dropdown_item, my);
        course.setAdapter(adapter);
        md();
    }

    public void md(){
        viewall.setOnClickListener(
                new View.OnClickListener(){
                    public  void onClick(View v){

                        Cursor res = myd.getAllstudent();
                        if (res.getCount()==0){
                            //
                            showmessage("error", "No Record Found in the database");
                            return;
                        }

                        StringBuffer buffer= new StringBuffer();

                        while(res.moveToNext()){
                            buffer.append("id:"+ res.getString(0)+ "\n");
                            buffer.append("Course:"+ res.getString(1)+ "\n");
                            buffer.append("reg:"+ res.getString(2)+ "\n");
                            buffer.append("in:"+ res.getString(3)+ "\n");
                            buffer.append("out:"+ res.getString(4)+ "\n\n");

                        }
                        //
                        showmessage("Data", buffer.toString());

                    }
                });
    }
    // error message code
    public void showmessage(String title, String message){

        AlertDialog.Builder builder= new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }





    public void  scan(View view){

        zXingScannerView=new ZXingScannerView(getApplicationContext());
        setContentView(zXingScannerView);
        zXingScannerView.setResultHandler(this);
        zXingScannerView.startCamera();
    }

    @Override
    protected void onPause() {
        super.onPause();
        zXingScannerView.stopCamera();
    }

    @Override
    public void handleResult(Result result) {
        name=result.getText().toString();

        out="YES";

        course.getSelectedItem().toString();

        Cursor cursorupdate = myd.getserachout(name,course.getSelectedItem().toString());
        if (cursorupdate.moveToFirst()) {

            myd.sout(out);
            Toast.makeText(this, "Sorry! "+ result.getText()+" has alraedy sign out", Toast.LENGTH_SHORT).show();

            return;

        }
        else{
            Toast.makeText(getApplicationContext(), "yAttendance for"+ result.getText()+"was succefully sign out", Toast.LENGTH_SHORT).show();
            return;

        }







    }
}
