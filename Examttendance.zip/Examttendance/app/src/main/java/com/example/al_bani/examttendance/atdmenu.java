package com.example.al_bani.examttendance;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

public class atdmenu extends AppCompatActivity {
    Button viewa, exit, about, signin,signout, view;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_atdmenu);
        signin = (Button) findViewById(R.id.signin);
        signout = (Button) findViewById(R.id.signout);
        about=(Button) findViewById(R.id.about);
        exit=(Button) findViewById(R.id.exit);
        md();
        
    }


    public void md() {

        signin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent =  new Intent(atdmenu.this, m.class);
                startActivity(intent);

            }
        });
        about.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent =  new Intent(atdmenu.this, about.class);
                startActivity(intent);
            }
        });
        signout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent =  new Intent(atdmenu.this, signout.class);
                startActivity(intent);
            }
        });




    }


}
