package com.example.al_bani.examttendance;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

public class home extends AppCompatActivity{
    Databasehelper stdb;
    Button log, exit, about, sstudent,attendance, view;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        stdb= new Databasehelper(this);
        log = (Button) findViewById(R.id.btnadmin);
        sstudent = (Button) findViewById(R.id.student);
        about=(Button) findViewById(R.id.about);
        attendance=(Button) findViewById(R.id.attendance);
        exit=(Button) findViewById(R.id.exit);
        d();
        mk();

    }

    public void mk(){
        exit.setOnClickListener(
                new View.OnClickListener(){
                    public  void onClick(View v){

                        Cursor res = stdb.getAllad();
                        if (res.getCount()==0){
                            //
                            showmessage("error", "No Record Found in the database");
                            return;
                        }

                        StringBuffer buffer= new StringBuffer();

                        while(res.moveToNext()){
                            buffer.append("id:"+ res.getString(0)+ "\n");
                            buffer.append("Course:"+ res.getString(1)+ "\n");
                            buffer.append("reg:"+ res.getString(2)+ "\n");
                            buffer.append("in:"+ res.getString(3)+ "\n");
                            buffer.append("out:"+ res.getString(4)+ "\n\n");

                        }
                        //
                        showmessage("ATTENDANCE", buffer.toString());

                    }
                });
    }
    // error message code
    public void showmessage(String title, String message){

        AlertDialog.Builder builder= new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }
    public void d() {

        log.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent =  new Intent(home.this, admin.class);
                startActivity(intent);

            }
        });
        about.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent =  new Intent(home.this, aboutus.class);
                startActivity(intent);
            }
        });
        attendance.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent =  new Intent(home.this, mdi.class);
                startActivity(intent);
            }
        });
        sstudent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent =  new Intent(home.this, adds.class);
                startActivity(intent);
            }
        });




    }

}