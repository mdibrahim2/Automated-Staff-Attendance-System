package com.example.al_bani.examttendance;

import android.database.Cursor;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class admin extends AppCompatActivity implements View.OnClickListener {
    Databasehelper my;
    EditText username,password, name, email,editsearch;
    Button save, viewall, update, Search, all;
    String search, edituser, editpass, editmail, editname;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);
        //new instance of database helper
        my = new Databasehelper(this);
        editsearch=(EditText) findViewById(R.id.edrc);
        username= (EditText) findViewById(R.id.username);
        name = (EditText) findViewById(R.id.name);
        password= (EditText) findViewById(R.id.password);

        email = (EditText) findViewById(R.id.email);
        save = (Button) findViewById(R.id.btnsave);
        viewall = (Button) findViewById(R.id.btnview);
        update=(Button) findViewById(R.id.update);
        update.setOnClickListener(this);
        all=(Button) findViewById(R.id.alld);
        all.setOnClickListener(this);

addData();
        mdi();
    }


    private void addData() {
        save.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        name.getText().toString();
                        username.getText().toString();
                        password.getText().toString();
                        name.getText().toString();

                        email.getText().toString();

                        if (name.equals("") || username.equals("") || password.equals("") || email.equals("")) {
                            Toast.makeText(admin.this, "Empty field is not Accepted", Toast.LENGTH_SHORT).show();

                        }
                        boolean isinserted = my.insertdata(name.getText().toString(), username.getText().toString(), password.getText().toString(),
                                email.getText().toString());
                        if (isinserted == true) {

                            Toast.makeText(admin.this, "Record inserted successfully", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(admin.this, "Data not inserted", Toast.LENGTH_LONG).show();
                        }

                    }
                }
        );
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.update) {
            search = editsearch.getText().toString();
            edituser = username.getText().toString();
            editpass = password.getText().toString();
            editname = name.getText().toString();

            editmail = email.getText().toString();
            if (search.equals("")) {
                Toast.makeText(this, "Please Enter admin Name to update", Toast.LENGTH_SHORT).show();
                return;

            }

            Cursor cursorupdate = my.getserach(search);
            if (cursorupdate.moveToFirst()) {


                if (editname.equals("") || edituser.equals("") || editpass.equals("") || editmail.equals("")) {
                    Toast.makeText(this, "Please field cant be empty", Toast.LENGTH_SHORT).show();
                    return;

                } else {

                    my.updatedata(editname, edituser, editpass, editmail);
                    Toast.makeText(this, "Record Sucessfully Updated", Toast.LENGTH_SHORT).show();
                    return;

                }}
            else{
                Toast.makeText(this, "No record to update", Toast.LENGTH_SHORT).show();
                return;

            }


        }


        if(v.getId() == R.id.alld) {
            search = editsearch.getText().toString();


            if (search.equals("")) {
                Toast.makeText(this, "Please select admin Name to delete", Toast.LENGTH_SHORT).show();
                return;

            }
            Cursor cursorupdate = my.getid(search);

            if (cursorupdate.moveToFirst()) {


                my.deleteall(search);
                Toast.makeText(this, "Record Sucessfully DELETED", Toast.LENGTH_SHORT).show();
                return;
            }


            else {
                Toast.makeText(this, "Data Not Found", Toast.LENGTH_SHORT).show();
                return;
            }}




    }

    public void mdi(){

        viewall.setOnClickListener(
                new View.OnClickListener(){
            public  void onClick(View v){

                Cursor res = my.getAlldata();
                if (res.getCount()==0){
                    //
                    showmessage("error", "No Record Found in the database");
                    return;
                }

                StringBuffer buffer= new StringBuffer();

                while(res.moveToNext()){
                    buffer.append("id:"+ res.getString(0)+ "\n");
                    buffer.append("name:"+ res.getString(1)+ "\n");
                    buffer.append("username:"+ res.getString(2)+ "\n");
                    buffer.append("password:"+ res.getString(3)+ "\n");
                    buffer.append("email:"+ res.getString(4)+ "\n\n");

                }
                //
                showmessage("Data", buffer.toString());

            }
        });
    }
    // error message code
    public void showmessage(String title, String message){

        AlertDialog.Builder builder= new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }






}
