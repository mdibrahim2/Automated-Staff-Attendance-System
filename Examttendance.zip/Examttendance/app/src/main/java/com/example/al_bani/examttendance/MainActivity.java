package com.example.al_bani.examttendance;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    // databse helper
    Databasehelper mydb;
    EditText username,password;
    Spinner spinner;
    Button login;
    String getspinner;
    ArrayList<String> mylist =new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //new instance of database helper
        mydb = new Databasehelper(this);


        spinner= (Spinner) findViewById(R.id.spinner2);
        username= (EditText) findViewById(R.id.editText2);
        password= (EditText) findViewById(R.id.editText3);
        login= (Button) findViewById(R.id.button3);

        // CREATE row for spinner
        mylist.add("STUDENT");
        mylist.add("ADMIN");

        //creating adapter for spinner
        ArrayAdapter<String> adapter= new ArrayAdapter<String>
                (MainActivity.this,
                android.R.layout.simple_spinner_dropdown_item,mylist);
        spinner.setAdapter(adapter);

        getspinner=spinner.getSelectedItem().toString();
        //login validation
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


            }
        });
    }

}
