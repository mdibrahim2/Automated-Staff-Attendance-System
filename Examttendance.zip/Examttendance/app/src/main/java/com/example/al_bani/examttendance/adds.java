package com.example.al_bani.examttendance;

import android.database.Cursor;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;

public class adds extends AppCompatActivity implements View.OnClickListener {
    Databasehelper mydb;
    EditText username,password, name, email, editsearch;
    Button save, viewall, all, update;
    String search;
    String edituser;
    String editpass;
    String editmail;
    EditText reg;
    Spinner level;
    String editname, editreg,editlevel, editemail;
    ArrayList<String> mylist =new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adds);
        //new instance of database helper
        mydb= new Databasehelper(this);
        editsearch = (EditText) findViewById(R.id.edrc);
        name = (EditText) findViewById(R.id.name);
        email = (EditText) findViewById(R.id.email);
        reg = (EditText) findViewById(R.id.reg);
        level =(Spinner) findViewById(R.id.level);
        save = (Button) findViewById(R.id.btnsave);
        viewall = (Button) findViewById(R.id.btnview);
        update=(Button) findViewById(R.id.update);

        // CREATE row for spinner
        mylist.add("LEVEL 100");
        mylist.add("LEVEL 200");
        mylist.add("LEVEL 300");
        mylist.add("LEVEL 400");
        mylist.add("LEVEL 500");

        //creating adapter for spinner
        ArrayAdapter<String> adapter= new ArrayAdapter<>
                (adds.this,
                        android.R.layout.simple_spinner_dropdown_item,mylist);
        level.setAdapter(adapter);

        update.setOnClickListener(this);
        all=(Button) findViewById(R.id.alld);
        all.setOnClickListener(this);
        add();
        mdi();

    }


    private void add() {
        save.setOnClickListener(
                new View.OnClickListener(){
                    @Override
                    public void onClick(View v) {

                        name.getText().toString();
                        reg.getText().toString();
                       level.getSelectedItem().toString();
                       email.getText().toString();

                        if (name.equals("") || email.equals("") || reg.equals("") || level.equals("")) {
                            Toast.makeText(adds.this, "Empty field is not Accepted", Toast.LENGTH_SHORT).show();
                        }
                            boolean isinserted = mydb.insertstudent(name.getText().toString(),
                                    level.getSelectedItem().toString(), reg.getText().toString(), email.getText().toString());
                            if (isinserted == true) {

                                Toast.makeText(adds.this, "Record inserted successfully", Toast.LENGTH_SHORT).show();
                            } else {
                                Toast.makeText(adds.this, "Data not inserted", Toast.LENGTH_LONG).show();
                            }


                        }

                }
        );
    }
    public void mdi(){

        viewall.setOnClickListener(
                new View.OnClickListener(){
                    public  void onClick(View v){

                        Cursor res = mydb.getAllstudent();
                        if (res.getCount()==0){
                            //
                            showmessage("error", "No Record Found in the database");
                            return;
                        }

                        StringBuffer buffer= new StringBuffer();

                        while(res.moveToNext()){
                            buffer.append("s_id:"+ res.getString(0)+ "\n");
                            buffer.append("name:"+ res.getString(1)+ "\n");
                            buffer.append("level:"+ res.getString(2)+ "\n");
                            buffer.append("reg"+ res.getString(3)+ "\n");
                            buffer.append("email:"+ res.getString(4)+ "\n\n");

                        }
                        //
                        showmessage("Data", buffer.toString());

                    }
                });
    }
    // error message code
    public void showmessage(String title, String message){

        AlertDialog.Builder builder= new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }

    @Override
    public void onClick(View v) {

        if (v.getId() == R.id.update) {
            search = editsearch.getText().toString();
            editname = name.getText().toString();
            edituser = reg.getText().toString();
            editpass = level.getSelectedItem().toString();
            editname = email.getText().toString();

            if (search.equals("")) {
                Toast.makeText(this, "Please Enter admin Name to update", Toast.LENGTH_SHORT).show();
                return;

            }

            Cursor cursorupdate = mydb.getserachs(search);
            if (cursorupdate.moveToFirst()) {


                if (editname.equals("") || edituser.equals("") || editpass.equals("") || editmail.equals("")) {
                    Toast.makeText(this, "Please field cant be empty", Toast.LENGTH_SHORT).show();
                    return;

                } else {

                    mydb.updatestd(editname, editpass, edituser, editmail);
                    Toast.makeText(this, "Record Sucessfully Updated", Toast.LENGTH_SHORT).show();
                    return;

                }}
            else{
                Toast.makeText(this, "No record to update", Toast.LENGTH_SHORT).show();
                return;

            }


        }


        if(v.getId() == R.id.alld) {
            search = editsearch.getText().toString();


            if (search.equals("")) {
                Toast.makeText(this, "Please select admin Name to delete", Toast.LENGTH_SHORT).show();
                return;

            }
            Cursor cursorupdate = mydb.getids(search);

            if (cursorupdate.moveToFirst()) {


                mydb.deletstd(search);
                Toast.makeText(this, "Record Sucessfully DELETED", Toast.LENGTH_SHORT).show();
                return;
            }


            else {
                Toast.makeText(this, "Data Not Found", Toast.LENGTH_SHORT).show();
                return;
            }}




    }



}
