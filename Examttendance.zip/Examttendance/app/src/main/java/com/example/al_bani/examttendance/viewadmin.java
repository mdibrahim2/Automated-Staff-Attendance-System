package com.example.al_bani.examttendance;

import android.database.Cursor;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class viewadmin extends AppCompatActivity {
    ListView list;
    ArrayList<String> listitem;
    ArrayAdapter adapter;
    Databasehelper mydb;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_viewadmin);
        mydb= new Databasehelper(this);
        listitem = new ArrayList<>();
        list= (ListView) findViewById(R.id.list);
        viewdata();
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String dini = list.getItemAtPosition(position).toString();
                Toast.makeText(viewadmin.this, ""+dini , Toast.LENGTH_SHORT).show();
            }
        });
    }

    public void viewdata(){
        Cursor res = mydb.getAlldata();
        if (res.getCount()==0){
            //
            showmessage("error", "No Record Found in the database");
            return;
        }



        while(res.moveToNext()){
            listitem.add("id:"+ res.getString(0)+ "\n");
            listitem.add("name:"+ res.getString(1)+ "\n");
            listitem.add("username:"+ res.getString(2)+ "\n");
            listitem.add("password:"+ res.getString(3)+ "\n");
            listitem.add("email:"+ res.getString(4)+ "\n\n");

        }
       adapter = new ArrayAdapter<>(this,  android.R.layout.simple_list_item_1, listitem);
        list.setAdapter(adapter);

    }
    // error message code
    public void showmessage(String title, String message){

        AlertDialog.Builder builder= new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }
}
